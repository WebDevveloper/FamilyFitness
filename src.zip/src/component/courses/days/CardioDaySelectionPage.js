import React, { useEffect, useState } from 'react';
import { Box, Button, Typography, Paper, useTheme, useMediaQuery } from '@mui/material';
import { getJSON, postJSON } from '../../../api';
import { useNavigate } from 'react-router-dom';

export default function CardioDaySelectionPage() {
  const navigate = useNavigate();
  const theme = useTheme();
  // для мелких экранов можно уменьшить размер кнопок
  const isXs = useMediaQuery(theme.breakpoints.down('sm'));

  const totalDays = 30;
  const purposeId = 3;

  const [currentDay, setCurrentDay] = useState(0);
  const [isOver, setIsOver] = useState(false);
  const [journalId, setJournalId] = useState(null);
  const [loading, setLoading] = useState(true);

  // Забираем прогресс и ID активной попытки
  useEffect(() => {
    (async () => {
      try {
        const { progress } = await getJSON('/api/courses/progress');
        const rec = progress.find(r => r.purposeId === purposeId);
        if (rec) {
          setCurrentDay(rec.currentDay);
          setIsOver(rec.isOver === 1);
          setJournalId(rec.journalId);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // выбор дня
  const handleDay = day => {
    if (day <= currentDay) {
      navigate(`/cardio-training/days/${day}`, { state: { journalId } });
    }
  };

  // кнопка «Начать сначала» доступна только если курс полностью пройден
  const handleReset = async () => {
    if (!isOver) return;
    await postJSON('/api/courses/reset', { purposeId });
    window.location.reload();
  };

  if (loading) return <Typography>Загрузка...</Typography>;

  return (
    <Paper
      sx={{
        p: 3,
        mt: 2,
        minHeight: '70vh',               // чуть больше, чтобы «заполнить» экран
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
      }}
    >
      <Typography variant="h5" align="center" gutterBottom>
        Выберите день курса
      </Typography>

      <Box
        sx={{
          display: 'grid',
          gap: 2,
          width: '100%',
          maxWidth: 900,
          // Для больших экранов 80px, для маленьких — 64px
          gridTemplateColumns: `repeat(auto-fit, minmax(${isXs ? 64 : 80}px, 1fr))`,
          py: 4,
        }}
      >
        {Array.from({ length: totalDays }, (_, i) => {
          const day = i + 1;
          const disabled = day > currentDay;
          let variant = 'outlined';
          let color = 'inherit';

          if (day < currentDay) {
            variant = 'contained';
            color = 'success';
          } else if (day === currentDay) {
            variant = 'contained';
            color = 'primary';
          }

          return (
            <Button
              key={day}
              variant={variant}
              color={color}
              disabled={disabled}
              onClick={() => handleDay(day)}
              sx={{
                height: isXs ? 64 : 80,
                fontSize: isXs ? '1rem' : '1.25rem',
                fontWeight: 500,
              }}
            >
              {day}
            </Button>
          );
        })}
      </Box>

      <Box textAlign="center" sx={{ mt: 2 }}>
        <Button
          variant="outlined"
          color="error"
          disabled={!isOver}
          onClick={handleReset}
        >
          Начать сначала
        </Button>
      </Box>
    </Paper>
  );
}
