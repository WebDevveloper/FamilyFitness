export async function getJSON(url) {
    const res = await fetch(url, { headers: { 'Content-Type': 'application/json' }});
    if (!res.ok) throw new Error(`Ошибка ${res.status}`);
    return res.json();
  }
  export async function postJSON(url, body) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!res.ok) throw new Error(`Ошибка ${res.status}`);
    return res.json();
  }