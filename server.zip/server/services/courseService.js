// const db = require('../config/db');
const { pool } = require('../config/db');

async function listPurposes() {
  const [rows] = await pool.query('SELECT id, name, count_day AS totalDays, calories FROM purpose');
  return rows;
}

async function listExercisesByPurpose(purposeId) {
  const [rows] = await pool.query(`
    SELECT e.id, e.name, e.about, e.how_to_do
      FROM purpose_config pc
      JOIN exercise e ON e.id = pc.exercise_id
     WHERE pc.purpose_id = ?
     ORDER BY pc.day, pc.id
  `, [purposeId]);
  return rows;
}

module.exports = { listPurposes, listExercisesByPurpose };