const router       = require('express').Router();
const authenticate = require('../middleware/authenticate');
const authorize    = require('../middleware/authorize');
const ctl          = require('../controllers/courseController');

// все операции с курсами — только для авторизованных пользователей
router.use(authenticate);

/**
 * GET  /api/courses/list
 *   — список программ
 */
router.get('/list', ctl.listPurposes);

/**
 * GET  /api/courses/exercises/:purposeId
 *   — упражнения по программе
 */
router.get('/exercises/:purposeId', ctl.listExercises);

/**
 * POST /api/courses/complete
 *   — отметить день выполненным
 */
router.post(
  '/complete',
  authorize('parent', 'child'),
  ctl.completeDay
);

/**
 * GET  /api/courses/progress
 *   — прогресс пользователя
 */
router.get(
  '/progress',
  authorize('parent', 'child'),
  ctl.getProgress
);

module.exports = router;