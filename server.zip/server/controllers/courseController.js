const courseService = require('../services/courseService');

/**
 * GET /api/courses/list
 * — вернуть список программ (purposes)
 */
async function listPurposes(req, res, next) {
  try {
    const list = await courseService.listPurposes();
    res.json(list);
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/courses/exercises/:purposeId
 * — вернуть упражнения для заданной программы
 */
async function listExercises(req, res, next) {
  try {
    const { purposeId } = req.params;
    const exercises = await courseService.listExercisesByPurpose(purposeId);
    res.json(exercises);
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/courses/complete
 * — отметить текущий день выполненным
 */
async function completeDay(req, res, next) {
  try {
    const userId    = req.user.id;
    const { dayId } = req.body;       // или другое поле, как договоритесь
    await courseService.markDayComplete(userId, dayId);
    res.json({ message: 'День отмечен как выполненный' });
  } catch (err) {
    next(err);
  }
}

/**
 * GET /api/courses/progress
 * — получить прогресс пользователя
 */
async function getProgress(req, res, next) {
  try {
    const userId  = req.user.id;
    const progress = await courseService.getProgress(userId);
    res.json(progress);
  } catch (err) {
    next(err);
  }
}

module.exports = {
  listPurposes,
  listExercises,
  completeDay,
  getProgress
};