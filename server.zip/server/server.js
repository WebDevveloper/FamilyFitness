require('dotenv').config();

const express = require('express');
const cors    = require('cors');
const app     = express();

// Инициализация подключения к БД
// const { initDB } = require('./config/db');
// initDB().catch(err => {
//   console.error('❌ Не удалось подключиться к БД:', err);
//   process.exit(1);
// });

app.use(cors({
  origin: 'http://localhost:3000',  // или '*' для разработки
  credentials: true
}));

// Разбор JSON
app.use(express.json());

// Подключаем маршруты
const apiRouter = require('./routes/index');
app.use('/api', apiRouter);

// Централизованный обработчик ошибок
const errorHandler = require('./middleware/errorHandler');
app.use(errorHandler);

// Запуск сервера
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Server is running on port ${PORT}`);
});
